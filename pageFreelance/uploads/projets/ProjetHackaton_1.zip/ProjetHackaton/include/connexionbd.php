<?php
    $conn = new PDO ("mysql:host=localhost;dbname=hackaton","root", "");
?>