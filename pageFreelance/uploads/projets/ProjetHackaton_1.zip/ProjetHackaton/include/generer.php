<?php 
    $nombre = rand(10,99);
    $lettre=chr(rand(65,90));
    $nombre1=rand(1000,9999);
    $id=$nombre . $lettre . $nombre1;
?>