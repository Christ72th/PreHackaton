<?php
    session_start();
    $dossierImages='ImagesUpload';
    $dossierExecutables= 'ExecutablesUpload';
    $dossierReadme= 'ReadmeUpload';
    $dossierSource= 'SourceUpload';

    //deplacement des fichiers executables
    if(!file_exists($dossierExecutables)){
        mkdir($dossierExecutables, 0777);
    }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
        if(isset($_FILES['FichierExe'])){
            $fichier = $_FILES['FichierExe'];
            $errorfichier = $fichier['error'];

            if ($errorfichier !== UPLOAD_ERR_OK) {
                echo 'Erreur lors du téléchargement : ' . $errorfichier;
            }
            $dossierFinal = $dossierExecutables . '/';
            $cheminAccessExe = $dossierFinal . $fichier['name'];

            if(!move_uploaded_file($fichier['tmp_name'], $cheminAccessExe)){
                echo 'Erreur de téléchargement';
            } else {
                header('location:Accueil.php');
            }
        }
        else{
            echo 'erreur';
        }
    }
    //deplacement des fichiers readme
    if(!file_exists($dossierReadme)){
        mkdir($dossierReadme, 0777);
    }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
        if(isset($_FILES['FichierReadme'])){
            $fichier = $_FILES['FichierReadme'];
            $errorfichier = $fichier['error'];

            if ($errorfichier !== UPLOAD_ERR_OK) {
                echo 'Erreur lors du téléchargement : ' . $errorfichier;
            }
            $dossierFinal = $dossierReadme . '/';
            $cheminAccessRm = $dossierFinal . $fichier['name'];

            if(!move_uploaded_file($fichier['tmp_name'], $cheminAccessRm)){
                echo 'Erreur de téléchargement';
            } else {
            }
        }
        else{
            echo 'erreur';
        }
    }
    //deplacement des fichiers Sources
    if(!file_exists($dossierSource)){
        mkdir($dossierSource, 0777);
    }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
        if(isset($_FILES['FichierSource'])){
            $fichier = $_FILES['FichierSource'];
            $errorfichier = $fichier['error'];

            if ($errorfichier !== UPLOAD_ERR_OK) {
                echo 'Erreur lors du téléchargement : ' . $errorfichier;
            }
            $dossierFinal = $dossierSource . '/';
            $cheminAccessSrc = $dossierFinal . $fichier['name'];

            if(!move_uploaded_file($fichier['tmp_name'], $cheminAccessSrc)){
                echo 'Erreur de téléchargement';
            } else {
                header('location:Accueil.php');
            }
        }
        else{
            echo 'erreur';
        }
    }
    //deplacement des fichiers Images
    if(!file_exists($dossierImages)){
        mkdir($dossierImages, 0777);
    }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
        if(isset($_FILES['Image'])){
            $fichier = $_FILES['Image'];
            $errorfichier = $fichier['error'];

            if ($errorfichier !== UPLOAD_ERR_OK) {
                echo 'Erreur lors du téléchargement : ' . $errorfichier;
            }
            $dossierFinal = $dossierImages . '/';
            $cheminAccessImg = $dossierFinal . $fichier['name'];

            if(!move_uploaded_file($fichier['tmp_name'], $cheminAccessImg)){
                echo 'Erreur de téléchargement';
            } else {
                header('location:Accueil.php');
            }
        }
        else{
            echo 'erreur';
        }
    }
    include('../include/connexionbd.php');
    include('../include/generer.php');
    try {
            $statut="En_cours";
        $stmt=$conn->prepare("INSERT INTO projets (id_projet,titre,descriptions,date_debut,date_fin,url_executable,url_images,url_readme,url_code_source,statut,nom_utilisateur_f) VALUES (:id_projet,:titre,:descriptions,now(),now(),:url_executable,:url_images,:url_readme,:url_code_source,:statut,:nom_utilisateur_f)");
        $stmt->bindParam(":id_projet",$id);
        $stmt->bindParam(":titre",$_POST['NomProjet']);
        $stmt->bindParam(":descriptions",$_POST['Description']);
        $stmt->bindParam(":url_executable",$cheminAccessExe);
        $stmt->bindParam(":url_images",$cheminAccessImg);
        $stmt->bindParam("url_code_source",$cheminAccessSrc);
        $stmt->bindParam("url_readme",$cheminAccessRm);
        $stmt->bindParam("statut",$statut);
        $stmt->bindParam(":nom_utilisateur_f",$_SESSION['Username']);
        if($stmt->execute()){
            header('location:Accueil.php');
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
?>