<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Freelance</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../style/style.css">
    <link rel="shortcut icon" href="../img/LogoHackaton.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header class="header">
        <nav class="navigation">
            <div class="logo">
                <img src="../img/LogoHackaton.png" alt="Logo Freelance Manager">
                <h1>Freelance Manager</h1>
            </div>
            <div class="NavLinks">
                <ul>
                    <li><a href="#"><img src="../img/Accueil.svg" alt="." class="icone">Tableau de Bord</a></li>
                    <li><a href="projets.html">Projets</a></li>
                    <li><a href="#" id="parametresBtn"><img src="../img/parametre.svg" alt="." class="icone">Paramètres</a></li>
                    <li><a href="../deconnexion.php"><img src="../img/Deconnexion.svg" alt="." class="icone">Déconnexion</a></li>
                </ul>
            </div>
            <img src="../img/menuHamburger.png" alt="Menu Hamburger" class="Menu-Hamburger">
        </nav>
    </header>
<?php
    session_start();
    if(isset($_SESSION['Username'])){ ?>
    <h1 class="mot">Bienvenue <span class="nom"><?php echo $_SESSION['Username']; ?></span> </h1>

    <main class="main-content">
        <section class="tableau-de-bord">
            <div class="container">
                <h2>Tableau de Bord</h2>

                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-tasks"></i> Projets en Cours</h5>
                                <p class="card-text">3 projets</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-file-invoice-dollar"></i> Factures Impayées</h5>
                                <p class="card-text">2 factures</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-envelope"></i> Nouveaux Messages</h5>
                                <p class="card-text">5 messages</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="projets-recents">
                    <h3><i class="fas fa-project-diagram"></i> Mes Projets </h3>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nom du Projet</th>
                                <th>Date de Début</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $id_projet=array();
                                include('../include/connexionbd.php');
                                try {
                                    $stmt1 = $conn->prepare("SELECT * FROM projets WHERE nom_utilisateur_f=:nom_utilisateur");
                                    $stmt1->bindParam(":nom_utilisateur",$_SESSION['Username']);
                                    $stmt1->execute();

                                } catch (PDOException $e) {
                                    $e->getMessage();
                                }
                                if($stmt1->rowCount()>0){
                                    $i=0;
                                    while ($row = $stmt1->fetch()) {
                                        $id_projet[$i]=$row["id_projet"];
                                        echo '<tr>';
                                            echo'<td>'.$row["titre"]. '</td>';
                                            echo'<td>'.$row["date_debut"]. '</td>';
                                            echo'<td>'.$row["statut"]. '</td>';
                                            echo'<td><a href="projet_details.php?id=' . $id_projet[$i] . '"><i class="fas fa-eye"></i> Voir</a> | <a href="commenter.html"><i class="fas fa-comment"></i> Commenter</a></td>';
                                        echo'</tr>';
                                        $i++;
                                }
                            }
                            else{
                                echo'<span>Aucun projet enregistre</span>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="deposer-projet">
                    <h3><i class="fas fa-plus-circle"></i> Déposer un Projet</h3>
                    <a href="deposer_projet.html" class="btn btn-primary"><i class="fas fa-upload"></i> Déposer un Nouveau Projet</a>
                </div>
            </div>
        </section>

        <div id="parametresModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Paramètres</h2>
                <ul>
                    <li><a href="profil.html"><i class="fas fa-user-edit"></i> Modifier le profil</a></li>
                    <li><a href="notifications.html"><i class="fas fa-bell"></i> Notifications</a></li>
                    <li><a href="securite.html"><i class="fas fa-shield-alt"></i> Sécurité</a></li>
                    <li><a href="cv.html"><i class="fas fa-file-alt"></i> Ajouter/Modifier CV</a></li>
                </ul>
            </div>
        </div>
    </main>
    <?php }
        else{
            header('location:connexionFreelance.php');
        }
        ?>
    <script src="../script.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>