public class JoueurTikTakToe{
    private string nomJoueurTikTakToe;
    private char symbole;

    //Selecteur et getteur

    public string NomJoueurTikTakToe{
        get{return nomJoueurTikTakToe;}
        set{nomJoueurTikTakToe = value;}
    }

    public char Symbole{
        get{return symbole;}
        set{symbole = value;}
    }

    //Constructeur par defaut

    public JoueurTikTakToe(int n){
        nomJoueurTikTakToe="Joueur"+n.ToString();

        if(n%2==0){
            Symbole='X';
        }
        else{
            Symbole='O';
        }
    }

    //Fonction pour placer un symbole
    public bool placerPoint(int n, int m, Matrice matrice){
        PointTikTakToe point = new PointTikTakToe(n-1, m-1);
        if(matrice.Taillex >= n && matrice.Tailley >= m){
            if(matrice.Mat[point.X, point.Y]=='\0'){
                matrice.Mat[point.X,point.Y]=Symbole;
                return true;
            }
            else{
                Console.WriteLine("Cette case est deja occupee");
                return false;
            }
        }
        else{
            Console.WriteLine("Valeurs trop grandes");
            return false;
        }
    }
    
//Gain ou perte
  /*  
    public bool aligne_vertical(Matrice M){
        int n=0,j=0;
        int[] tab=new int[M.Taillex] ;
        bool control=true;
        for(int i=0; i<M.Taillex; i++){
            while(int j<M.Tailley){
                tab=M.Mat[i;j];
                j++;
            }
        }
        for(i=0;i<tab.lenght;i++){
            if(tab[i]!=tab[i++]){
                control=false;
            }
        }
        return control;
    }*/
    public bool aligneDiagonale(Matrice M){
        bool gain=false;
        for(int i=0;i<M.Taillex;i++){
            if(M.Taillex<6){
                if(M.estPleine()==false &&(M.Mat[i%M.Taillex,i%M.Taillex]==M.Mat[(i+1)%M.Taillex,(i+1)%M.Taillex] && M.Mat[(i+2)%M.Taillex,(i+2)%M.Taillex]==M.Mat[(i+1)%M.Taillex,(i+1)%M.Taillex] && (M.Mat[i,i]==symbole))){
                    gain= true;
                }
            }
            /*else{
                i=n-2
                if( M.Mat[i,i]==M.Mat[i+1,i+1] && M.Mat[i+2,i+2]==M.Mat[i+1,i+1]){
                    gain= true;
                }
            }*/
        }
        
        return gain;
    }
}