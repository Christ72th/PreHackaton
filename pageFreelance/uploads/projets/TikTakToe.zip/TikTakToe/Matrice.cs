public class Matrice{
    private char [,] mat;
    private int taillex;
    private int tailley;

    public int Taillex{
        get{ return taillex; }
        set{ taillex=value; }
    }
    public int Tailley{
        get{ return tailley; }
        set{ tailley=value; }
    }
    public char [,] Mat{
        get{ return mat; }
        set{ mat=value; }
    }
//Initialiser la matrice
    public Matrice(int n){
        taillex=n;
        tailley=n;
        mat=new char [Taillex,Tailley];
    }

//Verification de l'etat de la matrice

    public bool estPleine(){
        for(int i=0; i<taillex; i++){
            for(int j=0; j<tailley; j++){
                if(mat[i,j]=='\0'){
                    return false;
                    break;
                }
                
            }
        }
        return true;
    }

    //Implementation des differents cas de gain

}
