public class PointTikTakToe{
    private int x;
    private int y;
    //Getteur et setteur
    public int X{
        get{ return x; }
        set{ x=value; }
    }
    public int Y{
        get{ return y; }
        set{ y=value; }
    }

    //Constructeur

    public PointTikTakToe(int x, int y){
        X=x;
        Y=y;
    }
}