﻿// See https://aka.ms/new-console-template for more information
public class Program{

    public static void afficherMatrice(Matrice mat)
    {
        Console.Clear();
        for (int i = 0; i < mat.Taillex; i++)
        {
            Console.WriteLine("\t\t -----------------------");
            Console.Write("\t\t|"); 

            for (int j = 0; j < mat.Tailley; j++)
            {
                Console.Write(" "+mat.Mat[i, j]+" \t|");
            }

            Console.WriteLine();
            Console.WriteLine("\t\t -----------------------");
        }
    }
 
    

    public static void Main(string[] Args){

        Console.WriteLine("\t\t\tBienvenue dans l'application Tik Tak Toe!");
        Console.WriteLine("\t\t\t\t==========Niveau 1========== ");
        Console.WriteLine("\t\t\t\t==========Niveau 2========== ");
        Console.WriteLine("\t\t\t\t==========Niveau 3========== ");
        Console.WriteLine("");
        Console.Write("Choissisez un niveau : ");
        JoueurTikTakToe j1 = new JoueurTikTakToe(1);
        JoueurTikTakToe j2 = new JoueurTikTakToe(2);
        int choix=-1;
        choix=int.Parse(Console.ReadLine());
         
        int cmp=0;
        switch(choix){
            case 1:
                Matrice maMatrice = new Matrice(3);
                Console.WriteLine("");
                Console.WriteLine("Pour gagner ce niveau vous devez aligner 3 symboles.");
                Console.WriteLine("\t\tVous etes le "+j1.NomJoueurTikTakToe);
                Console.WriteLine("\t\tVous jouez contre : "+j2.NomJoueurTikTakToe);
                Console.WriteLine("");
                do{
                    if(cmp%2== 0){
                        Console.WriteLine("\t\t ========Votre Tour========");

                        Console.Write("Entrer les donnees d'un point : ");
                        int abs= int.Parse(Console.ReadLine());
                        int ord= int.Parse(Console.ReadLine());
                        Console.WriteLine(abs+";"+ord);
                        if(j1.placerPoint(abs, ord, maMatrice)){
                            cmp++; 
                        }
                        afficherMatrice(maMatrice);
                            
                    }
                    else{
                        Console.WriteLine("\t\t ========Tour Machine========");
                        Random rand= new Random();
                        int abs= rand.Next(1,maMatrice.Taillex+1);
                        int ord=  rand.Next(1,maMatrice.Tailley+1);
                        Console.WriteLine(abs+";"+ord);
                        if(j2.placerPoint(abs, ord, maMatrice)){
                            cmp++; 
                        }
                        afficherMatrice(maMatrice);
                    }
                }while(maMatrice.estPleine()!=true && (j1.aligneDiagonale(maMatrice)==false || j2.aligneDiagonale(maMatrice)==false));
                if(j1.aligneDiagonale(maMatrice)==true){
                    Console.WriteLine(j1.NomJoueurTikTakToe+" a gagne.");
                }
                if(j2.aligneDiagonale(maMatrice)==true){
                    Console.WriteLine(j2.NomJoueurTikTakToe+" a gagne.");
                }
                break;
            case 2:
                maMatrice=new Matrice(5);
                Console.WriteLine("");
                Console.WriteLine("Pour gagner ce niveau vous devez aligner 3 symboles.");
                Console.WriteLine("\t\tVous etes le "+j1.NomJoueurTikTakToe);
                Console.WriteLine("\t\tVous jouez contre : "+j2.NomJoueurTikTakToe);
                Console.WriteLine("");
                do{
                    if(cmp%2== 0){
                        Console.WriteLine("\t\t ========Votre Tour========");

                        Console.Write("Entrer les donnees d'un point : ");
                        int abs= int.Parse(Console.ReadLine());
                        int ord= int.Parse(Console.ReadLine());
                        Console.WriteLine(abs+";"+ord);
                        if(j1.placerPoint(abs, ord, maMatrice)){
                            cmp++; 
                        }
                        afficherMatrice(maMatrice);
                            
                    }
                    else{
                        Console.WriteLine("\t\t ========Tour Machine========");
                        Random rand= new Random();
                        int abs= rand.Next(1,maMatrice.Taillex+1);
                        int ord=  rand.Next(1,maMatrice.Tailley+1);
                        Console.WriteLine(abs+";"+ord);
                        if(j2.placerPoint(abs, ord, maMatrice)){
                            cmp++; 
                        }
                        afficherMatrice(maMatrice);
                    }
                }while(maMatrice.estPleine()!=true && (j1.aligneDiagonale(maMatrice)==false || j2.aligneDiagonale(maMatrice)==false));
                if(j1.aligneDiagonale(maMatrice)==true){
                    Console.WriteLine(j1.NomJoueurTikTakToe+" a gagne.");
                }
                if(j2.aligneDiagonale(maMatrice)==true){
                    Console.WriteLine(j2.NomJoueurTikTakToe+" a gagne.");
                }
                break;
            case 3:
                maMatrice = new Matrice(7);

                break;
            default:
                Console.WriteLine("Veuillez faire un bon choix");
                break;

        }
        
           
    }

}